Avancée:
1) Terminé et fonctionnel
2) Terminé et fonctionnel
3) Terminé et fonctionnel
4) Terminé et fonctionnel
5) Avancé mais pas terminé; on ne peut importer que les images sans commentaires et stockées avec des char (pas en ASCII; type P5)
6) Commencé mais ne fonctionne pas