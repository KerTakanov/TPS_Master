//
// Created by Meimei on 14/11/2017.
//

#ifndef TP1_TESTIMAGE2D_H
#define TP1_TESTIMAGE2D_H

int testImage2D();

#endif //TP1_TESTIMAGE2D_H
