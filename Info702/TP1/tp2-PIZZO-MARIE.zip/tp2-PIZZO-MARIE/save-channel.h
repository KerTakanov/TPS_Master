//
// Created by Meimei on 28/11/2017.
//

#ifndef TP1_SAVE_CHANNEL_H
#define TP1_SAVE_CHANNEL_H

#include "Color.h"
#include "Image2D.h"

int save_channel(Image2D<Color>& img);

#endif //TP1_SAVE_CHANNEL_H
