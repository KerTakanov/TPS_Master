#include <iostream>
#include "testImage2D.h"

int main() {
    testImage2D();

    return 0;
}